<?php
/**
 * Vueltito Split payment gateway (Mercado Pago marketplace_fee).
 *
 * EXPERIMENTAL / DISABLED BY DEFAULT. This gateway routes the buyer payment
 * through Mercado Pago Checkout Pro with a marketplace_fee equal to the
 * donation, so the donation is separated at capture time and the merchant
 * never holds it. It must stay off until Vueltito completes the legal custody
 * review (it implies Vueltito receiving donation funds as marketplace owner).
 *
 * Enable per-store only after legal sign-off: WooCommerce > Settings > Vueltito
 * "Split enabled", then WooCommerce > Payments.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Vueltito_Split_Gateway extends WC_Payment_Gateway
{
    private $vueltito_settings;

    public function __construct(array $vueltito_settings)
    {
        $this->vueltito_settings = $vueltito_settings;
        $this->id = 'vueltito_split';
        $this->method_title = 'Vueltito (donación + Mercado Pago)';
        $this->method_description = 'Cobra la compra con Mercado Pago y separa la donación como marketplace fee de Vueltito.';
        $this->has_fields = false;
        $this->supports = ['products', 'refunds'];

        $this->init_form_fields();
        $this->init_settings();

        $this->title = $this->get_option('title', 'Pagar con Mercado Pago (incluye tu donación)');
        $this->description = $this->get_option('description', '');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    public function init_form_fields(): void
    {
        $this->form_fields = [
            'enabled' => [
                'title' => 'Activar',
                'type' => 'checkbox',
                'label' => 'Activar el gateway de split Vueltito (requiere aprobación legal)',
                'default' => 'no'
            ],
            'title' => [
                'title' => 'Título',
                'type' => 'text',
                'default' => 'Pagar con Mercado Pago (incluye tu donación)'
            ],
            'description' => [
                'title' => 'Descripción',
                'type' => 'textarea',
                'default' => ''
            ]
        ];
    }

    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order) {
            return ['result' => 'failure'];
        }

        $donation_cents = (int) $order->get_meta('_vueltito_donation_amount_cents');
        $total_cents = (int) round((float) $order->get_total() * 100);

        $payload = [
            'externalOrderId' => (string) $order_id,
            'orderTotalCents' => $total_cents,
            'donationAmountCents' => max($donation_cents, 0),
            'currency' => $order->get_currency(),
            'successUrl' => $this->get_return_url($order),
            'failureUrl' => wc_get_checkout_url()
        ];

        // No donation on this order: fall back to a plain preference is out of
        // scope here. The split gateway is meant for donation-bearing orders.
        if ($payload['donationAmountCents'] <= 0) {
            wc_add_notice('Esta orden no tiene una donación asociada.', 'error');
            return ['result' => 'failure'];
        }

        $response = wp_remote_post(
            rtrim($this->vueltito_settings['api_base_url'], '/') . '/v1/plugin/woocommerce/split-preference',
            [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-Vueltito-Installation-Id' => $this->vueltito_settings['installation_id'],
                    'X-Vueltito-Api-Key' => $this->vueltito_settings['api_key']
                ],
                'body' => wp_json_encode($payload),
                'timeout' => 15
            ]
        );

        if (is_wp_error($response)) {
            wc_add_notice('No se pudo iniciar el pago con Vueltito. Intentá de nuevo.', 'error');
            return ['result' => 'failure'];
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($status >= 400 || empty($body['initPoint'])) {
            wc_add_notice('El pago con Vueltito no está disponible en este momento.', 'error');
            return ['result' => 'failure'];
        }

        $order->update_meta_data('_vueltito_mp_preference_id', (string) ($body['preferenceId'] ?? ''));
        $order->save();
        $order->update_status('pending', 'Esperando pago en Mercado Pago (Vueltito split).');

        return [
            'result' => 'success',
            'redirect' => (string) $body['initPoint']
        ];
    }
}

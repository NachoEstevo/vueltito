=== Vueltito Donations ===
Contributors: vueltito
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 0.4.7
License: GPLv2 or later

Adds an opt-in Vueltito donation fee to WooCommerce Classic Checkout and Checkout Blocks.

== Description ==
The plugin requests a quote from Vueltito Core, stores buyer consent evidence, writes quote/consent/campaign metadata on the WooCommerce order, and sends idempotent order lifecycle events to Core.

Vueltito v1 does not custody donation funds. The merchant collects the donation as a visible WooCommerce fee and Vueltito tracks merchant owed-to-NGO obligations plus monthly platform billing.

== Configuration ==
Set the Core API URL, installation id, API key, and fee taxability under WooCommerce > Settings > Vueltito.

Production API URL:
https://vueltito-api-production.up.railway.app

== Installation ==
1. Upload `vueltito-donations-0.4.7.zip` from Plugins > Add New > Upload Plugin.
2. Activate Vueltito Donations.
3. Open WooCommerce > Vueltito.
4. Confirm the Core API URL, installation id, and API key.
5. Click "Probar conexion con Vueltito".
6. Place a test order and confirm the donation appears before payment.

== Changelog ==
= 0.4.7 =
* Production install release for WooCommerce.
* Classic Checkout and Checkout Blocks support.
* Core connection health check.
* Order lifecycle event retry queue.
* Visible opt-in donation fee with order metadata.

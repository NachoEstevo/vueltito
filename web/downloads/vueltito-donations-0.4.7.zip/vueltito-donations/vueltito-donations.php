<?php
/**
 * Plugin Name: Vueltito Donations
 * Description: Adds opt-in Vueltito donation fees and reports WooCommerce order events to Vueltito Core. Supports Classic Checkout and Checkout Blocks.
 * Version: 0.4.7
 * Author: Vueltito
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Vueltito_Donations_Plugin
{
    private const VERSION = '0.4.7';
    private const OPTION_KEY = 'vueltito_donations_settings';
    private const QUEUE_OPTION_KEY = 'vueltito_pending_events';
    private const FLUSH_HOOK = 'vueltito_flush_events';
    private const MAX_ATTEMPTS = 8;
    private const PRIVACY_NOTICE_VERSION = '2026-06-leaderboard-v1';

    public static function init(): void
    {
        $plugin = new self();
        add_action('admin_init', [$plugin, 'register_settings']);
        add_action('admin_menu', [$plugin, 'register_settings_page']);
        add_action('wp_enqueue_scripts', [$plugin, 'enqueue_checkout_assets']);
        add_action('woocommerce_review_order_before_payment', [$plugin, 'render_classic_checkout']);
        add_action('woocommerce_cart_calculate_fees', [$plugin, 'add_donation_fee']);
        add_action('woocommerce_checkout_create_order', [$plugin, 'save_order_meta'], 20, 2);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$plugin, 'save_order_meta_store_api'], 20, 2);
        add_action('wp_ajax_vueltito_quote', [$plugin, 'ajax_quote']);
        add_action('wp_ajax_nopriv_vueltito_quote', [$plugin, 'ajax_quote']);
        add_action('wp_ajax_vueltito_consent', [$plugin, 'ajax_consent']);
        add_action('wp_ajax_nopriv_vueltito_consent', [$plugin, 'ajax_consent']);
        add_action('woocommerce_order_status_processing', [$plugin, 'send_paid_event']);
        add_action('woocommerce_order_status_completed', [$plugin, 'send_paid_event']);
        add_action('woocommerce_order_status_cancelled', [$plugin, 'send_cancelled_event']);
        add_action('woocommerce_order_status_failed', [$plugin, 'send_failed_event']);
        add_action('woocommerce_order_refunded', [$plugin, 'send_refunded_event'], 10, 2);
        add_action('woocommerce_blocks_loaded', [$plugin, 'register_blocks_integration']);
        add_action('woocommerce_blocks_checkout_block_registration', [$plugin, 'register_checkout_block_integration']);
        add_filter('cron_schedules', [$plugin, 'register_cron_schedule']);
        add_action(self::FLUSH_HOOK, [$plugin, 'flush_pending_events']);
        add_filter('woocommerce_payment_gateways', [$plugin, 'register_split_gateway']);
        register_deactivation_hook(__FILE__, [self::class, 'on_deactivation']);
    }

    /**
     * Registers the experimental Mercado Pago split gateway only when a
     * developer flag enables it and the merchant explicitly opts in.
     */
    public function register_split_gateway(array $gateways): array
    {
        if (!$this->split_gateway_available() || empty($this->setting('split_enabled'))) {
            return $gateways;
        }
        require_once __DIR__ . '/includes/class-vueltito-split-gateway.php';
        $settings = $this->settings();
        $gateways[] = function () use ($settings) {
            return new Vueltito_Split_Gateway($settings);
        };
        return $gateways;
    }

    public static function on_deactivation(): void
    {
        wp_clear_scheduled_hook(self::FLUSH_HOOK);
    }

    public function register_cron_schedule(array $schedules): array
    {
        $schedules['vueltito_five_minutes'] = [
            'interval' => 300,
            'display' => 'Every five minutes (Vueltito)'
        ];
        return $schedules;
    }

    public function register_settings(): void
    {
        register_setting('vueltito_donations', self::OPTION_KEY);
        add_settings_section('vueltito_main', 'Vueltito', '__return_false', 'vueltito_donations');
        $fields = [
            'api_base_url' => 'Core API URL',
            'installation_id' => 'Installation ID',
            'api_key' => 'API key',
            'fee_taxable' => 'Fee taxable'
        ];
        if ($this->split_gateway_available()) {
            $fields['split_enabled'] = 'Split gateway (experimental - requiere aprobación legal)';
        }

        foreach ($fields as $key => $label) {
            add_settings_field($key, $label, [$this, 'render_setting_field'], 'vueltito_donations', 'vueltito_main', [
                'key' => $key,
                'label' => $label
            ]);
        }
    }

    public function register_settings_page(): void
    {
        add_submenu_page(
            'woocommerce',
            'Vueltito',
            'Vueltito',
            'manage_woocommerce',
            'vueltito-donations',
            [$this, 'render_settings_page']
        );
    }

    public function render_setting_field(array $args): void
    {
        $settings = $this->settings();
        $key = $args['key'];
        if ($key === 'fee_taxable' || $key === 'split_enabled') {
            printf(
                '<input type="checkbox" name="%s[%s]" value="1" %s />',
                esc_attr(self::OPTION_KEY),
                esc_attr($key),
                checked(!empty($settings[$key]), true, false)
            );
            return;
        }

        printf(
            '<input class="regular-text" type="%s" name="%s[%s]" value="%s" />',
            $key === 'api_key' ? 'password' : 'text',
            esc_attr(self::OPTION_KEY),
            esc_attr($key),
            esc_attr($settings[$key] ?? '')
        );
    }

    public function render_settings_page(): void
    {
        $connection_notice = null;
        if (isset($_POST['vueltito_check_connection'])) {
            check_admin_referer('vueltito_check_connection');
            $connection_notice = $this->connection_notice();
        }

        echo '<div class="wrap"><h1>Vueltito</h1><form method="post" action="options.php">';
        settings_fields('vueltito_donations');
        do_settings_sections('vueltito_donations');
        submit_button();
        echo '</form>';

        if ($connection_notice) {
            printf(
                '<div class="notice notice-%s"><p>%s</p></div>',
                esc_attr($connection_notice['type']),
                esc_html($connection_notice['message'])
            );
        }

        echo '<hr /><h2>Conexion</h2><p>Probá que esta tienda pueda hablar con Core usando las credenciales guardadas.</p>';
        echo '<form method="post">';
        wp_nonce_field('vueltito_check_connection');
        submit_button('Probar conexion con Vueltito', 'secondary', 'vueltito_check_connection', false);
        echo '</form></div>';
    }

    public function enqueue_checkout_assets(): void
    {
        if (
            !function_exists('is_checkout')
            || !is_checkout()
            || $this->is_order_received_page()
            || $this->is_blocks_checkout()
        ) {
            return;
        }

        $config = $this->checkout_config();

        wp_enqueue_script(
            'vueltito-classic-checkout',
            plugins_url('assets/classic-checkout.js', __FILE__),
            ['jquery'],
            $this->asset_version('assets/classic-checkout.js'),
            true
        );
        wp_localize_script('vueltito-classic-checkout', 'VueltitoCheckout', $config);
    }

    private function is_blocks_checkout(): bool
    {
        global $post;

        return $post instanceof WP_Post && function_exists('has_block') && has_block('woocommerce/checkout', $post);
    }

    private function is_order_received_page(): bool
    {
        return function_exists('is_order_received_page') && is_order_received_page();
    }

    public function checkout_config(): array
    {
        return [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vueltito_checkout'),
            'privacyNoticeVersion' => self::PRIVACY_NOTICE_VERSION
        ];
    }

    public function render_classic_checkout(): void
    {
        echo '<div class="vueltito-checkout">';
        woocommerce_form_field('vueltito_accept_donation', [
            'type' => 'checkbox',
            'class' => ['form-row-wide'],
            'label' => 'Sumar una donacion con Vueltito',
            'required' => false
        ]);
        echo '<p class="form-row form-row-wide"><select id="vueltito_campaign_id" name="vueltito_campaign_id"></select></p>';
        echo '<div class="vueltito-leaderboard" hidden>';
        woocommerce_form_field('vueltito_leaderboard_opt_in', [
            'type' => 'checkbox',
            'class' => ['form-row-wide'],
            'label' => 'Aparecer en la pagina de transparencia',
            'required' => false
        ]);
        woocommerce_form_field('vueltito_public_alias', [
            'type' => 'text',
            'class' => ['form-row-first'],
            'label' => 'Alias publico',
            'required' => false
        ]);
        woocommerce_form_field('vueltito_donor_email', [
            'type' => 'email',
            'class' => ['form-row-last'],
            'label' => 'Email privado',
            'required' => false
        ]);
        echo '<p class="form-row form-row-wide vueltito-leaderboard-note">Mostramos solo tu alias. Tu email no se publica.</p>';
        echo '</div>';
        echo '</div>';
    }

    public function ajax_quote(): void
    {
        check_ajax_referer('vueltito_checkout', 'nonce');
        $response = $this->request_quote(sanitize_text_field($_POST['selectedMode'] ?? 'round_up'));
        if (is_wp_error($response)) {
            wp_send_json_error(['message' => $response->get_error_message()], 502);
        }

        wp_send_json($response);
    }

    public function ajax_consent(): void
    {
        check_ajax_referer('vueltito_checkout', 'nonce');
        $accepted = ($_POST['accepted'] ?? '0') === '1';
        $campaign_id = sanitize_text_field($_POST['campaignId'] ?? '');
        $donor = $this->sanitize_donor_payload($_POST);

        $response = $this->apply_consent($accepted, $campaign_id, $donor);
        if (is_wp_error($response)) {
            wp_send_json_error(['message' => $response->get_error_message()], 502);
        }

        wp_send_json($response);
    }

    /**
     * Requests a fresh quote from Core for the current cart and caches it in session.
     *
     * @return array|WP_Error
     */
    private function request_quote(string $selected_mode)
    {
        $subtotal = WC()->cart ? (float) WC()->cart->get_subtotal() : 0.0;
        $payload = [
            'installationId' => $this->setting('installation_id'),
            'cartHash' => WC()->cart ? WC()->cart->get_cart_hash() : wp_generate_uuid4(),
            'subtotalCents' => $this->to_cents($subtotal),
            'currency' => get_woocommerce_currency(),
            'selectedMode' => $selected_mode
        ];
        $response = $this->call_api('/v1/plugin/woocommerce/quote', $payload);
        if (is_wp_error($response)) {
            return $response;
        }

        WC()->session->set('vueltito_quote', $response);
        return $response;
    }

    /**
     * Applies or clears the donation consent. Shared by Classic (admin-ajax)
     * and Checkout Blocks (Store API extensionCartUpdate callback).
     *
     * @return array|WP_Error
     */
    private function apply_consent(bool $accepted, string $campaign_id, array $donor = [])
    {
        if (!$accepted) {
            WC()->session->set('vueltito_donation', null);
            return ['consentId' => null, 'fee' => ['amountCents' => 0]];
        }

        $quote = WC()->session->get('vueltito_quote');
        if (empty($quote['id'])) {
            $quote = $this->request_quote('round_up');
            if (is_wp_error($quote)) {
                return $quote;
            }
        }

        if ($campaign_id === '') {
            $campaign_id = (string) ($quote['defaultCampaign']['id'] ?? '');
        }

        $payload = [
            'quoteId' => $quote['id'],
            'accepted' => true,
            'campaignId' => $campaign_id,
            'uiSnapshotHash' => hash('sha256', wp_json_encode($quote)),
            'buyerSessionHash' => hash('sha256', WC()->session->get_customer_id())
        ];
        if (!empty($donor['leaderboardOptIn'])) {
            $payload['leaderboardOptIn'] = true;
            $payload['publicAlias'] = $donor['publicAlias'];
            $payload['donorEmail'] = $donor['donorEmail'];
            $payload['privacyNoticeVersion'] = $donor['privacyNoticeVersion'];
        }
        $response = $this->call_api('/v1/plugin/woocommerce/consents', $payload);

        if (is_wp_error($response)) {
            // The cached quote may have expired while the buyer was deciding.
            // Re-quote once against the current cart and retry.
            $quote = $this->request_quote('round_up');
            if (is_wp_error($quote)) {
                return $quote;
            }
            $payload['quoteId'] = $quote['id'];
            $payload['uiSnapshotHash'] = hash('sha256', wp_json_encode($quote));
            $response = $this->call_api('/v1/plugin/woocommerce/consents', $payload);
            if (is_wp_error($response)) {
                return $response;
            }
        }

        $session_donation = [
            'quoteId' => $quote['id'],
            'consentId' => $response['consentId'],
            'campaignId' => $campaign_id,
            'amountCents' => $response['fee']['amountCents'],
            'currency' => $response['fee']['currency'],
            'leaderboardOptIn' => !empty($payload['leaderboardOptIn']),
            'privacyNoticeVersion' => $payload['privacyNoticeVersion'] ?? self::PRIVACY_NOTICE_VERSION
        ];
        if (!empty($payload['publicAlias'])) {
            $session_donation['publicAlias'] = $payload['publicAlias'];
        }

        WC()->session->set('vueltito_donation', $session_donation);
        return $response;
    }

    public function add_donation_fee(): void
    {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        $donation = WC()->session ? WC()->session->get('vueltito_donation') : null;
        if (empty($donation['amountCents'])) {
            return;
        }

        // Anti-fraud: never charge a donation on an empty or zero-subtotal
        // cart (donation-only cart pattern).
        if (!WC()->cart || WC()->cart->is_empty() || (float) WC()->cart->get_subtotal() <= 0) {
            WC()->session->set('vueltito_donation', null);
            return;
        }

        WC()->cart->add_fee(
            'Donacion Vueltito',
            ((int) $donation['amountCents']) / 100,
            (bool) $this->setting('fee_taxable')
        );
    }

    public function save_order_meta(WC_Order $order, array $data): void
    {
        $this->persist_donation_meta($order);
    }

    /**
     * Checkout Blocks (Store API) order-creation path.
     *
     * @param WC_Order        $order
     * @param WP_REST_Request $request
     */
    public function save_order_meta_store_api($order, $request): void
    {
        if ($order instanceof WC_Order) {
            $this->persist_donation_meta($order);
        }
    }

    private function persist_donation_meta(WC_Order $order): void
    {
        $donation = WC()->session ? WC()->session->get('vueltito_donation') : null;
        if (!$donation) {
            return;
        }

        $order->update_meta_data('_vueltito_quote_id', $donation['quoteId']);
        $order->update_meta_data('_vueltito_consent_id', $donation['consentId']);
        $order->update_meta_data('_vueltito_campaign_id', $donation['campaignId']);
        $order->update_meta_data('_vueltito_donation_amount_cents', (int) $donation['amountCents']);
        $order->update_meta_data('_vueltito_leaderboard_opt_in', !empty($donation['leaderboardOptIn']) ? 'yes' : 'no');
        if (!empty($donation['publicAlias'])) {
            $order->update_meta_data('_vueltito_public_alias', $donation['publicAlias']);
        }
        $order->update_meta_data(
            '_vueltito_privacy_notice_version',
            $donation['privacyNoticeVersion'] ?? self::PRIVACY_NOTICE_VERSION
        );
    }

    public function send_paid_event(int $order_id): void
    {
        $this->send_order_event($order_id, 'paid');
    }

    public function send_cancelled_event(int $order_id): void
    {
        $this->send_order_event($order_id, 'cancelled');
    }

    public function send_failed_event(int $order_id): void
    {
        $this->send_order_event($order_id, 'failed');
    }

    public function send_refunded_event(int $order_id, int $refund_id): void
    {
        $this->send_order_event($order_id, 'refunded');
    }

    public function register_blocks_integration(): void
    {
        if (function_exists('woocommerce_store_api_register_update_callback')) {
            woocommerce_store_api_register_update_callback([
                'namespace' => 'vueltito',
                'callback' => [$this, 'handle_blocks_cart_update']
            ]);
        }
    }

    public function register_checkout_block_integration($integration_registry): void
    {
        if (!interface_exists('\Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface')) {
            return;
        }

        $integration_registry->register(new class($this) implements \Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface {
            private $plugin;

            public function __construct(Vueltito_Donations_Plugin $plugin)
            {
                $this->plugin = $plugin;
            }

            public function get_name()
            {
                return 'vueltito';
            }

            public function initialize()
            {
                $this->plugin->register_blocks_checkout_script();
            }

            public function get_script_handles()
            {
                return ['vueltito-blocks-checkout'];
            }

            public function get_editor_script_handles()
            {
                return [];
            }

            public function get_script_data()
            {
                return $this->plugin->checkout_config();
            }
        });
    }

    public function register_blocks_checkout_script(): void
    {
        if (wp_script_is('vueltito-blocks-checkout', 'registered')) {
            return;
        }

        wp_register_script(
            'vueltito-blocks-checkout',
            plugins_url('assets/blocks-checkout.js', __FILE__),
            ['wp-element', 'wp-plugins', 'wp-data', 'wc-blocks-checkout', 'wc-settings'],
            $this->asset_version('assets/blocks-checkout.js'),
            true
        );
    }

    private function asset_version(string $relative_path): string
    {
        $path = __DIR__ . '/' . ltrim($relative_path, '/');
        if (!file_exists($path)) {
            return self::VERSION;
        }

        return self::VERSION . '-' . (string) filemtime($path);
    }

    /**
     * Store API extensionCartUpdate callback. Runs server-side when the
     * Checkout Blocks widget toggles the donation; the Store API recalculates
     * fees afterwards, so the donation fee appears/disappears atomically in
     * the returned cart.
     *
     * @param array $data ['accepted' => bool, 'campaignId' => string]
     */
    public function handle_blocks_cart_update(array $data): void
    {
        $accepted = !empty($data['accepted']);
        $campaign_id = sanitize_text_field((string) ($data['campaignId'] ?? ''));
        $donor = $this->sanitize_donor_payload($data);

        $result = $this->apply_consent($accepted, $campaign_id, $donor);
        if (is_wp_error($result)) {
            // Fail closed: never charge a donation whose consent was not recorded.
            WC()->session->set('vueltito_donation', null);
        }
    }

    private function sanitize_donor_payload(array $data): array
    {
        $opt_in = !empty($data['leaderboardOptIn']) || !empty($data['vueltito_leaderboard_opt_in']);
        $alias = sanitize_text_field((string) (
            $data['publicAlias']
            ?? $data['vueltito_public_alias']
            ?? ''
        ));
        $email = sanitize_email((string) (
            $data['donorEmail']
            ?? $data['vueltito_donor_email']
            ?? ''
        ));
        $version = sanitize_text_field((string) (
            $data['privacyNoticeVersion']
            ?? self::PRIVACY_NOTICE_VERSION
        ));

        if (!$opt_in || $alias === '' || $email === '' || !is_email($email)) {
            return ['leaderboardOptIn' => false];
        }

        return [
            'leaderboardOptIn' => true,
            'publicAlias' => $alias,
            'donorEmail' => $email,
            'privacyNoticeVersion' => $version ?: self::PRIVACY_NOTICE_VERSION
        ];
    }

    private function send_order_event(int $order_id, string $status): void
    {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $amount_cents = (int) $order->get_meta('_vueltito_donation_amount_cents');
        if ($amount_cents <= 0) {
            return;
        }

        $payload = [
            'eventId' => sprintf('woo-%d-%s', $order_id, $status),
            'externalOrderId' => (string) $order_id,
            'status' => $status,
            'currency' => $order->get_currency(),
            'orderTotalCents' => $this->to_cents((float) $order->get_total()),
            'donationAmountCents' => $amount_cents,
            'quoteId' => (string) $order->get_meta('_vueltito_quote_id'),
            'consentId' => (string) $order->get_meta('_vueltito_consent_id'),
            'campaignId' => (string) $order->get_meta('_vueltito_campaign_id'),
            'occurredAt' => gmdate('c')
        ];

        if ($this->deliver_event($payload) === 'retryable') {
            $this->queue_event($payload);
        }
    }

    /**
     * Attempts a single delivery of an order event to Core.
     * Core dedupes by eventId, so redelivery is always safe.
     *
     * @return string 'delivered' | 'permanent' | 'retryable'
     */
    private function deliver_event(array $payload): string
    {
        $response = $this->call_api_raw('/v1/plugin/woocommerce/order-events', $payload);
        if (is_wp_error($response)) {
            return 'retryable'; // network/timeout
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        if ($status < 400) {
            return 'delivered';
        }
        if ($status === 408 || $status === 429 || $status >= 500) {
            return 'retryable';
        }

        // Other 4xx: validation/auth problems that retrying will not fix.
        error_log(sprintf('[vueltito] order event %s permanently rejected with HTTP %d', $payload['eventId'], $status));
        return 'permanent';
    }

    private function queue_event(array $payload): void
    {
        $queue = get_option(self::QUEUE_OPTION_KEY, []);
        if (!is_array($queue)) {
            $queue = [];
        }

        $queue[$payload['eventId']] = [
            'payload' => $payload,
            'attempts' => isset($queue[$payload['eventId']]['attempts'])
                ? (int) $queue[$payload['eventId']]['attempts']
                : 0,
            'nextAt' => time() + 60
        ];
        update_option(self::QUEUE_OPTION_KEY, $queue, false);

        if (!wp_next_scheduled(self::FLUSH_HOOK)) {
            wp_schedule_event(time() + 300, 'vueltito_five_minutes', self::FLUSH_HOOK);
        }
    }

    /**
     * WP-Cron handler: retries queued order events with exponential backoff.
     */
    public function flush_pending_events(): void
    {
        $queue = get_option(self::QUEUE_OPTION_KEY, []);
        if (!is_array($queue) || $queue === []) {
            wp_clear_scheduled_hook(self::FLUSH_HOOK);
            return;
        }

        $now = time();
        foreach ($queue as $event_id => $entry) {
            if (!isset($entry['payload']) || ((int) ($entry['nextAt'] ?? 0)) > $now) {
                continue;
            }

            $result = $this->deliver_event($entry['payload']);
            if ($result === 'delivered' || $result === 'permanent') {
                unset($queue[$event_id]);
                continue;
            }

            $attempts = ((int) ($entry['attempts'] ?? 0)) + 1;
            if ($attempts >= self::MAX_ATTEMPTS) {
                error_log(sprintf('[vueltito] order event %s dropped after %d attempts', (string) $event_id, $attempts));
                unset($queue[$event_id]);
                continue;
            }

            $queue[$event_id]['attempts'] = $attempts;
            // 2m, 4m, 8m, ... capped at 6h between attempts.
            $queue[$event_id]['nextAt'] = $now + min(6 * HOUR_IN_SECONDS, 60 * (2 ** $attempts));
        }

        update_option(self::QUEUE_OPTION_KEY, $queue, false);
        if ($queue === []) {
            wp_clear_scheduled_hook(self::FLUSH_HOOK);
        }
    }

    /**
     * Low-level Core API call. Returns the raw wp_remote_post result
     * (array) or WP_Error on transport failure.
     */
    private function call_api_raw(string $path, array $payload)
    {
        return wp_remote_post(rtrim($this->setting('api_base_url'), '/') . $path, [
            'headers' => [
                'Content-Type' => 'application/json',
                'X-Vueltito-Installation-Id' => $this->setting('installation_id'),
                'X-Vueltito-Api-Key' => $this->setting('api_key')
            ],
            'body' => wp_json_encode($payload),
            'timeout' => 10
        ]);
    }

    private function call_api(string $path, array $payload)
    {
        $response = $this->call_api_raw($path, $payload);
        if (is_wp_error($response)) {
            return $response;
        }

        $status = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($status >= 400) {
            return new WP_Error('vueltito_api_error', 'Vueltito API rejected request', ['status' => $status, 'body' => $body]);
        }

        return $body;
    }

    private function connection_notice(): array
    {
        if (!$this->setting('api_base_url') || !$this->setting('installation_id') || !$this->setting('api_key')) {
            return [
                'type' => 'error',
                'message' => 'Completá API URL, Installation ID y API key antes de probar la conexión.'
            ];
        }

        $response = wp_remote_get(rtrim($this->setting('api_base_url'), '/') . '/v1/plugin/woocommerce/health', [
            'headers' => [
                'X-Vueltito-Installation-Id' => $this->setting('installation_id'),
                'X-Vueltito-Api-Key' => $this->setting('api_key')
            ],
            'timeout' => 10
        ]);

        if (is_wp_error($response)) {
            return [
                'type' => 'error',
                'message' => 'No se pudo conectar con Vueltito Core: ' . $response->get_error_message()
            ];
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($status >= 400) {
            return [
                'type' => 'error',
                'message' => sprintf('Vueltito Core rechazó las credenciales (HTTP %d).', $status)
            ];
        }

        $campaign = is_array($body) ? (string) ($body['defaultCampaign']['name'] ?? '') : '';
        $health_status = is_array($body) ? (string) ($body['status'] ?? '') : '';
        if ($health_status === 'disabled') {
            $reason = is_array($body) ? (string) ($body['reason'] ?? '') : '';
            return [
                'type' => 'error',
                'message' => $reason
                    ? sprintf('Credenciales válidas, pero la tienda está deshabilitada: %s.', $reason)
                    : 'Credenciales válidas, pero la tienda está deshabilitada.'
            ];
        }

        return [
            'type' => 'success',
            'message' => $campaign
                ? sprintf('Conexión validada. Campaña default: %s.', $campaign)
                : 'Conexión validada.'
        ];
    }

    private function settings(): array
    {
        $defaults = [
            'api_base_url' => 'https://vueltito-api-production.up.railway.app',
            'installation_id' => '',
            'api_key' => '',
            'fee_taxable' => false,
            'split_enabled' => false
        ];

        return array_merge($defaults, get_option(self::OPTION_KEY, []));
    }

    private function setting(string $key): string
    {
        $settings = $this->settings();
        return (string) ($settings[$key] ?? '');
    }

    private function split_gateway_available(): bool
    {
        $enabled = defined('VUELTITO_ENABLE_SPLIT_GATEWAY') && VUELTITO_ENABLE_SPLIT_GATEWAY;
        return (bool) apply_filters('vueltito_enable_split_gateway', $enabled);
    }

    private function to_cents(float $amount): int
    {
        return (int) round($amount * 100);
    }
}

Vueltito_Donations_Plugin::init();

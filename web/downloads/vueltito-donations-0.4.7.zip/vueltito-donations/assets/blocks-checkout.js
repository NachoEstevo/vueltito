/**
 * Vueltito — Checkout Blocks integration.
 *
 * Renders an opt-in donation widget in the Checkout Blocks order summary via
 * the ExperimentalOrderMeta slot. Quote fetching reuses the admin-ajax
 * endpoints (shared WC session with Classic); consent + fee application go
 * through the Store API extensionCartUpdate callback so cart totals refresh
 * atomically.
 */
(function () {
  var MAX_BOOT_ATTEMPTS = 20;
  var FALLBACK_PRIVACY_NOTICE_VERSION = "2026-06-leaderboard-v1";
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function boot(attempt) {
    var wp = window.wp || {};
    var wc = window.wc || {};
    var element = wp.element;
    var plugins = wp.plugins;
    var blocksCheckout = wc.blocksCheckout;
    var settings = wc.wcSettings || window.wcSettings || {};
    var config = window.VueltitoCheckout;

    if (!config && settings.getSetting) {
      config = settings.getSetting("vueltito_data", null);
    }

    if (!element || !plugins || !blocksCheckout || !config) {
      if (attempt < MAX_BOOT_ATTEMPTS) {
        window.setTimeout(function () {
          boot(attempt + 1);
        }, 100);
      }
      return;
    }
    if (!blocksCheckout.ExperimentalOrderMeta || !blocksCheckout.extensionCartUpdate) {
      if (attempt < MAX_BOOT_ATTEMPTS) {
        window.setTimeout(function () {
          boot(attempt + 1);
        }, 100);
      }
      return;
    }

  var el = element.createElement;
  var useState = element.useState;
  var useEffect = element.useEffect;

  function fetchQuote() {
    var body = new URLSearchParams({
      action: "vueltito_quote",
      nonce: config.nonce,
      selectedMode: "round_up"
    });
    return window
      .fetch(config.ajaxUrl, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: body.toString()
      })
      .then(function (response) {
        if (!response.ok) {
          throw new Error("quote_failed");
        }
        return response.json();
      });
  }

  function formatAmount(amountCents, currency) {
    try {
      return (amountCents / 100).toLocaleString("es-AR", {
        style: "currency",
        currency: currency || "ARS",
        minimumFractionDigits: 2
      });
    } catch (err) {
      return "$" + (amountCents / 100).toFixed(2);
    }
  }

  function privacyNoticeVersion() {
    return config.privacyNoticeVersion || FALLBACK_PRIVACY_NOTICE_VERSION;
  }

  function buildDonorPayload(leaderboardOptIn, publicAlias, donorEmail) {
    var alias = String(publicAlias || "").trim();
    var email = String(donorEmail || "").trim();
    if (!leaderboardOptIn || !alias || !EMAIL_RE.test(email)) {
      return {};
    }

    return {
      leaderboardOptIn: true,
      publicAlias: alias,
      donorEmail: email,
      privacyNoticeVersion: privacyNoticeVersion()
    };
  }

  function pushConsent(accepted, campaignId, donor) {
    var data = Object.assign(
      { accepted: accepted, campaignId: campaignId || "" },
      donor || {}
    );
    return blocksCheckout.extensionCartUpdate({
      namespace: "vueltito",
      data: data
    });
  }

  function VueltitoDonation() {
    var quoteState = useState(null);
    var quote = quoteState[0];
    var setQuote = quoteState[1];

    var acceptedState = useState(false);
    var accepted = acceptedState[0];
    var setAccepted = acceptedState[1];

    var campaignState = useState("");
    var campaignId = campaignState[0];
    var setCampaignId = campaignState[1];

    var leaderboardState = useState(false);
    var leaderboardOptIn = leaderboardState[0];
    var setLeaderboardOptIn = leaderboardState[1];

    var aliasState = useState("");
    var publicAlias = aliasState[0];
    var setPublicAlias = aliasState[1];

    var emailState = useState("");
    var donorEmail = emailState[0];
    var setDonorEmail = emailState[1];

    var busyState = useState(false);
    var busy = busyState[0];
    var setBusy = busyState[1];

    var failedState = useState(false);
    var failed = failedState[0];
    var setFailed = failedState[1];

    useEffect(function () {
      var cancelled = false;
      fetchQuote()
        .then(function (response) {
          if (cancelled) {
            return;
          }
          setQuote(response);
          if (response.defaultCampaign && response.defaultCampaign.id) {
            setCampaignId(response.defaultCampaign.id);
          }
        })
        .catch(function () {
          if (!cancelled) {
            setFailed(true);
          }
        });
      return function () {
        cancelled = true;
      };
    }, []);

    // If Core is unreachable, render nothing: the donation is optional and
    // must never block checkout.
    if (failed || !quote) {
      return null;
    }

    function syncConsent(nextAccepted, nextCampaignId, nextLeaderboardOptIn, nextAlias, nextEmail) {
      setBusy(true);
      pushConsent(
        nextAccepted,
        nextCampaignId,
        buildDonorPayload(nextLeaderboardOptIn, nextAlias, nextEmail)
      )
        .catch(function () {
          // Fail closed in the UI too: server clears the donation on error.
          setAccepted(false);
        })
        .then(function () {
          setBusy(false);
        });
    }

    function onToggle(event) {
      var nextAccepted = !!event.target.checked;
      setAccepted(nextAccepted);
      syncConsent(nextAccepted, campaignId, leaderboardOptIn, publicAlias, donorEmail);
    }

    function onCampaignChange(event) {
      var nextCampaignId = event.target.value;
      setCampaignId(nextCampaignId);
      if (accepted) {
        syncConsent(true, nextCampaignId, leaderboardOptIn, publicAlias, donorEmail);
      }
    }

    function onLeaderboardChange(event) {
      var nextOptIn = !!event.target.checked;
      setLeaderboardOptIn(nextOptIn);
      if (accepted) {
        syncConsent(true, campaignId, nextOptIn, publicAlias, donorEmail);
      }
    }

    function onAliasChange(event) {
      setPublicAlias(event.target.value);
    }

    function onEmailChange(event) {
      setDonorEmail(event.target.value);
    }

    function syncDonorIdentity() {
      if (accepted && leaderboardOptIn) {
        syncConsent(true, campaignId, true, publicAlias, donorEmail);
      }
    }

    var campaigns = quote.allowedCampaigns || [];
    var amountLabel = formatAmount(quote.amountCents, quote.currency);

    var children = [
      el(
        "label",
        { key: "optin", className: "vueltito-blocks__optin" },
        el("input", {
          key: "checkbox",
          type: "checkbox",
          checked: accepted,
          disabled: busy,
          onChange: onToggle
        }),
        " Sumar " + amountLabel + " como donaci\u00f3n"
      )
    ];

    if (accepted && campaigns.length > 0) {
      children.push(
        el(
          "select",
          {
            key: "campaign",
            className: "vueltito-blocks__campaign",
            value: campaignId,
            disabled: busy,
            onChange: onCampaignChange,
            "aria-label": "Eleg\u00ed la causa de tu donaci\u00f3n"
          },
          campaigns.map(function (campaign) {
            return el("option", { key: campaign.id, value: campaign.id }, campaign.name);
          })
        )
      );
      children.push(
        el(
          "p",
          { key: "note", className: "vueltito-blocks__note" },
          "El 100% de tu donaci\u00f3n llega a la organizaci\u00f3n. Pod\u00e9s quitarla antes de pagar."
        )
      );
      children.push(
        el(
          "label",
          { key: "leaderboard", className: "vueltito-blocks__leaderboard" },
          el("input", {
            key: "leaderboard-checkbox",
            type: "checkbox",
            checked: leaderboardOptIn,
            disabled: busy,
            onChange: onLeaderboardChange
          }),
          " Aparecer en la p\u00e1gina de transparencia"
        )
      );
      if (leaderboardOptIn) {
        children.push(
          el(
            "div",
            { key: "identity", className: "vueltito-blocks__identity" },
            el("input", {
              key: "alias",
              type: "text",
              value: publicAlias,
              disabled: busy,
              placeholder: "Alias p\u00fablico",
              onChange: onAliasChange,
              onBlur: syncDonorIdentity
            }),
            el("input", {
              key: "email",
              type: "email",
              value: donorEmail,
              disabled: busy,
              placeholder: "Email privado",
              onChange: onEmailChange,
              onBlur: syncDonorIdentity
            }),
            el(
              "p",
              { key: "identity-note", className: "vueltito-blocks__note" },
              "Mostramos solo tu alias. Tu email no se publica."
            )
          )
        );
      }
    }

    return el("div", { className: "vueltito-blocks" }, children);
  }

  plugins.registerPlugin("vueltito-donation", {
    render: function () {
      return el(
        blocksCheckout.ExperimentalOrderMeta,
        null,
        el(VueltitoDonation, null)
      );
    },
    scope: "woocommerce-checkout"
  });
  }

  boot(0);
})();

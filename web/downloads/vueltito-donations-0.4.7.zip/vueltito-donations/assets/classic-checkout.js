(function ($) {
  function post(action, payload) {
    return $.post(VueltitoCheckout.ajaxUrl, {
      action: action,
      nonce: VueltitoCheckout.nonce,
      ...payload
    });
  }

  function renderCampaigns(campaigns) {
    const select = $("#vueltito_campaign_id");
    select.empty();
    campaigns.forEach(function (campaign) {
      select.append($("<option />").val(campaign.id).text(campaign.name));
    });
  }

  async function refreshDonation() {
    const accepted = $("#vueltito_accept_donation").is(":checked");
    if (!accepted) {
      await post("vueltito_consent", { accepted: "0" });
      $("body").trigger("update_checkout");
      return;
    }

    const quote = await post("vueltito_quote", {
      selectedMode: "round_up"
    });
    renderCampaigns(quote.allowedCampaigns || []);

    await post("vueltito_consent", {
      accepted: "1",
      campaignId: $("#vueltito_campaign_id").val() || quote.defaultCampaign.id
    });
    $("body").trigger("update_checkout");
  }

  $(document.body).on("change", "#vueltito_accept_donation,#vueltito_campaign_id", refreshDonation);
})(jQuery);


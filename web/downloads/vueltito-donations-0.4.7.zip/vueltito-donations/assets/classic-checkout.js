(function ($) {
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function post(action, payload) {
    return $.post(VueltitoCheckout.ajaxUrl, {
      action: action,
      nonce: VueltitoCheckout.nonce,
      ...payload
    });
  }

  function privacyNoticeVersion() {
    return VueltitoCheckout.privacyNoticeVersion || "2026-06-leaderboard-v1";
  }

  function renderCampaigns(campaigns) {
    const select = $("#vueltito_campaign_id");
    select.empty();
    campaigns.forEach(function (campaign) {
      select.append($("<option />").val(campaign.id).text(campaign.name));
    });
  }

  function syncLeaderboardVisibility() {
    const accepted = $("#vueltito_accept_donation").is(":checked");
    const leaderboard = $(".vueltito-leaderboard");
    leaderboard.prop("hidden", !accepted);

    if (accepted && $("#vueltito_leaderboard_opt_in").is(":checked")) {
      autofillDonorFields();
    }
  }

  function autofillDonorFields() {
    const aliasField = $("#vueltito_public_alias");
    const emailField = $("#vueltito_donor_email");
    const firstName = String($("#billing_first_name").val() || "").trim();
    const email = String($("#billing_email").val() || "").trim();

    if (!aliasField.val() && firstName) {
      aliasField.val(firstName);
    }
    if (!emailField.val() && email) {
      emailField.val(email);
    }
  }

  function donorPayload() {
    if (!$("#vueltito_leaderboard_opt_in").is(":checked")) {
      return {};
    }

    autofillDonorFields();
    const alias = String($("#vueltito_public_alias").val() || "").trim();
    const email = String($("#vueltito_donor_email").val() || "").trim();
    if (!alias || !EMAIL_RE.test(email)) {
      return {};
    }

    return {
      leaderboardOptIn: "1",
      publicAlias: alias,
      donorEmail: email,
      privacyNoticeVersion: privacyNoticeVersion()
    };
  }

  async function refreshDonation() {
    const accepted = $("#vueltito_accept_donation").is(":checked");
    syncLeaderboardVisibility();

    if (!accepted) {
      await post("vueltito_consent", { accepted: "0" });
      $("body").trigger("update_checkout");
      return;
    }

    const quote = await post("vueltito_quote", {
      selectedMode: "round_up"
    });
    renderCampaigns(quote.allowedCampaigns || []);

    await post("vueltito_consent", {
      accepted: "1",
      campaignId: $("#vueltito_campaign_id").val() || quote.defaultCampaign.id,
      ...donorPayload()
    });
    $("body").trigger("update_checkout");
  }

  let refreshTimer = null;
  function scheduleRefresh() {
    window.clearTimeout(refreshTimer);
    refreshTimer = window.setTimeout(refreshDonation, 250);
  }

  $(document.body).on(
    "change",
    "#vueltito_accept_donation,#vueltito_campaign_id,#vueltito_leaderboard_opt_in",
    scheduleRefresh
  );
  $(document.body).on("input blur", "#vueltito_public_alias,#vueltito_donor_email", scheduleRefresh);
  $(document.body).on("change blur", "#billing_first_name,#billing_email", function () {
    if ($("#vueltito_accept_donation").is(":checked")) {
      autofillDonorFields();
    }
  });
  syncLeaderboardVisibility();
})(jQuery);
